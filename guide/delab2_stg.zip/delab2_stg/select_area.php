<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>STEP 1</title>

  <link rel="stylesheet" href="css/0-3-A1.css">
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

</hdead>
<body>

<form name="step1" action="./select_date.php" method='post'>
 <div class="main">
      <div class="btn-wrapper">
        <p>エリアを選択してください</p>
        <div class="select-btn guide-select">
          <select name="area" require>
            <option value="" hidden>未選択<font size="6">▼</font></option>
            <option value="kinki" >近畿（京都）</option>
            <option value="kanto" >関東</option>
          </select>
        </div>

        <p>名所か道案内か選択してください</p>
        <div class="select-btn guide-select">
          <select name="style" require>
            <option value="" hidden>未選択<font size="2">▼</font></option>
            <option value="1" >名所ガイド</option>
            <option value="2" >道案内ガイド</option>
          </select>
        </div>
        <p></p>

       <input class = "btn resistration" type="submit" value="Next">
        <p></p>
       <input class = "btn resistration" type="reset" value="入力内容をリセットする">
      </div>
 </div>
 </form> 


 </body>
</html>
