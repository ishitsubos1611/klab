<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>カレンダー</title>

  <link rel="stylesheet" href="css/0-3-A1.css">
  <link rel="stylesheet" href="css/calender.css">

  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>



</head>
<body margin:auto; text-align:center;>
<?php 
 $area = $_POST['area'];
 $style = $_POST['style'];
?>

<form name="step1" action="./registration.html" method='post'>

 <div id="cal"></div>

    <?php
    function weekdayColor_get($i) {
      if ($i == 0) return '#ff0000'; else return '#77EEFF';
    }
    function color_get($i, $days, $day, $thismonth, $month) {
      if ($i == 0) return '#FF99CC'; elseif(($days == $day) && ($thismonth == $month)) return '#ffff00';else return '#ffffff';
    }
    $m = $_GET['m'];
    if ($m) {
      $year = date('Y', strtotime($m . '01'));
      $month = date('n', strtotime($m . '01'));
    } else {
      $year = date('Y');
      $month = date('n');
    }
    $day = date('j');
    $thismonth = date('n');
    $weekday = array('日', '月', '火', '水', '木', '金', '土');
    echo '<p><table id="calender">';
    echo '<caption>';
    echo '<a href="?m=' . date('Ym', mktime(0, 0, 0, $month - 1 , 1, $year)) . '" class="year"> &lt;　</a> ' . $year . '年' . $month . '月';
    echo ' <a href="?m=' . date('Ym', mktime(0, 0, 0, $month + 1 , 1, $year)) . '" class="year">　&gt;</a>';
    echo '</caption><tbody><tr>';
    $i = 0;
    while ($i <= 6) {
      $c = weekdayColor_get($i);
      echo '<th style="background-color : '.$c.';">' . $weekday[$i] . '</th>';
      $i++;
    }
    echo '</tr><tr>';
    $i = 0;
    while ($i != date('w', mktime(0, 0, 0, $month, 1, $year))) {
      echo '<td style="background-color : #ffffff;">　</td>';
      $i++;
    }
    for ($days = 1; checkdate($month, $days, $year); $days++) {
      if ($i > 6) {
        echo '</tr><tr>';
        $i = 0;
      }
      $c = color_get($i, $days, $day, $thismonth, $month);
      echo '<td style="background-color : ' . $c . '"; id="day";>' .$days.'</td>';
      $i++;
    }
    while ($i < 7) {
      echo '<td style="background-color : #ffffff;">　</td>';
      $i++;
    }
    echo '</tr></tbody></table><p>';

    ?>

  </div>

 <script>
      var idnum = [];
      var idnumber = 0;
      $("#calender td").on("click",function(){
        var text = document.getElementById('day').textContent;
        //var text = day.textContent;
        //alert('クリックした日付は' + text + 'です')
        var boardingTime = "9:00";
        var endTime = "10:00";
        var requiredTime = 60;
        var lang = "JP";
        var fee = 1500;
        var numOfppl = 10;
        var user = [['A',2]];
        idnum.push(idnumber);
        /*for (var i = 0; i < idnum.length; i++) {
          $('#cal').append('<div id="guide'+idnum[i]+'" class="guide"><p>　(人気)　二条城ガイド '+idnum[i]+'</p>'
          +'<table id="states"><tr><td>Boarding time</td><td>'+boardingTime+'</td></tr>'
          +'<tr><td>END</td><td>'+endTime+'</td><td>('+requiredTime+'min)</td></tr>'
          +'<tr><td>Language</td><td>'+lang+'</td></tr>'
          +'<tr><td>Total fee</td><td>¥'+fee+'</td><td>('+numOfppl+'名)</td></tr></table>'
          +'<form action="guideDelete.php" method="post"><input type="hidden" name="id" value="i"/><input id="detail" type="submit" value="detail"></form></div>');
          $('#btn-a').val(i);
        }*/
        $('#cal').append('<div id="guide'+idnumber+'" class="guide"><p>　(人気)　二条城ガイド '+idnumber+'</p>'
        +'<table id="states"><tr><td>Boarding time</td><td>'+boardingTime+'</td></tr>'
        +'<tr><td>END</td><td>'+endTime+'</td><td>('+requiredTime+'min)</td></tr>'
        +'<tr><td>Language</td><td>'+lang+'</td></tr>'
        +'<tr><td>Total fee</td><td>¥'+fee+'</td><td>('+numOfppl+'名)</td></tr></table>'
        +'<form  id="form'+idnumber+'" action="guideDelete.php" method="post"><input type="hidden" name="id" value="'+idnumber+'"/><input id="detail" type="submit" value="detail"></form></div>');

        idnumber = idnumber + 1;


      })

      $("#calender td").addEventListener("click",function(e){
    if(e.target.classList.contains("calendar td")) {
        alert('クリックした日付は' + e.target.dataset.date + 'です')
    }
})
 </script>

<input name = "date" type="hidden" >

 <div class="main">
        <p>日付を入力して登録か変更を選択して下さい</p>
       <p>
        <input type=text size=8 name=date>(2019年9月30日の場合は20190930を入力）
        <div class="select-btn guide-select">
          <select name="mode" require>
            <option value="regist" >登録</option>
            <option value="change" >変更</option>
          </select>
        </div>
        <p></p>
      </div>

        <p></p>

       <input class = "btn resistration" type="submit" value="Next">
        <p></p>
       <input class = "btn resistration" type="reset" value="入力内容をリセットする">
      </div>

 </div>

</form>
 </body>
</html>
